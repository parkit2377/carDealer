import { Component } from '@angular/core';

@Component({
  selector: 'app-add-update-cars',
  templateUrl: './add-update-cars.component.html',
  styleUrls: ['./add-update-cars.component.scss']
})
export class AddUpdateCarsComponent {

}
